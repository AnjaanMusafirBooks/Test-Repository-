(function(){
"use strict";
const $=s=>document.querySelector(s);
const esc=t=>String(t??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const rs=n=>"₹"+n;
const link=b=>"book.html?book="+encodeURIComponent(b.id);

function price(b,big=false){
  const off=b.mrp>b.price?Math.round((1-b.price/b.mrp)*100):0;
  return `<div class="price${big?" big":""}">${big?`<p class="plabel">EXCLUSIVE EBOOK PRICE</p>`:""}<span class="now">${rs(b.price)}</span>${off?`<s>${rs(b.mrp)}</s><span class="off">${off}% OFF</span>`:""}</div>`;
}
function buy(b,cls="btn"){
  return b.checkout?`<a class="${cls} primary" href="${esc(b.checkout)}" target="_blank" rel="noopener">अभी खरीदें</a>`:`<span class="${cls} off-btn">जल्द उपलब्ध</span>`;
}
function badge(b){return b.popular?`<span class="badge">Popular</span>`:"";}
function card(b){
  return `<article class="card" data-category="${esc(b.category)}">${badge(b)}<button class="wish" data-wish="${esc(b.id)}" aria-label="बाद में पढ़ने के लिए save करें">♡</button><a href="${link(b)}"><img src="${esc(b.cover)}" alt="${esc(b.title)} — eBook cover" loading="lazy"></a><p class="mini-label">${esc(b.category)}</p><h3>${esc(b.title)}</h3><p class="sub">${esc(b.subtitle)}</p><p class="meta">${esc(b.author)} · ${b.pages} पेज</p>${price(b)}<div class="actions"><a class="btn" href="${link(b)}">विवरण</a>${buy(b)}</div></article>`;
}
function list(a){return "<ul>"+(a||[]).map(x=>`<li>${esc(x)}</li>`).join("")+"</ul>";}

function home(){
  const f=BOOKS.find(b=>b.featured), fs=$("#featured");
  if(f&&fs)fs.innerHTML=`<div class="wrap featured"><a class="featured-cover" href="${link(f)}"><img src="${esc(f.cover)}" alt="${esc(f.title)}"></a><div><p class="eyebrow dark">EDITOR'S PICK</p>${badge(f)}<h2>${esc(f.title)}</h2><p class="sub">${esc(f.subtitle)}</p><p>${esc(f.desc)}</p>${price(f,true)}<div class="actions"><a class="btn" href="${link(f)}">किताब देखें</a>${buy(f)}</div></div></div>`;
  renderGrid("all");
  const hc=$("#herocovers"); if(hc)hc.innerHTML=BOOKS.slice(0,4).map(b=>`<img src="${esc(b.cover)}" alt="">`).join("");
  document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderGrid(btn.dataset.filter)}));
  document.querySelectorAll("[data-filter]").forEach(x=>{if(!x.classList.contains("filter"))x.addEventListener("click",()=>{setTimeout(()=>{document.querySelectorAll(".filter").forEach(y=>y.classList.toggle("active",y.dataset.filter===x.dataset.filter));renderGrid(x.dataset.filter)},0)})});
  document.addEventListener("click",e=>{const w=e.target.closest("[data-wish]");if(!w)return;e.preventDefault();let a=JSON.parse(localStorage.getItem("am_wishlist")||"[]");a=a.includes(w.dataset.wish)?a.filter(x=>x!==w.dataset.wish):[...a,w.dataset.wish];localStorage.setItem("am_wishlist",JSON.stringify(a));w.classList.toggle("saved",a.includes(w.dataset.wish));w.textContent=a.includes(w.dataset.wish)?"♥":"♡"});
}
function renderGrid(filter){
  const g=$("#grid");if(!g)return;
  const list=filter==="all"?BOOKS:BOOKS.filter(b=>b.category===filter||b.tags.includes(filter));
  g.innerHTML=list.map(card).join("");
  const saved=JSON.parse(localStorage.getItem("am_wishlist")||"[]");
  g.querySelectorAll(".wish").forEach(w=>{if(saved.includes(w.dataset.wish)){w.classList.add("saved");w.textContent="♥"}});
  g.querySelectorAll(".wish").forEach(w=>w.addEventListener("click",e=>{e.preventDefault();let a=JSON.parse(localStorage.getItem("am_wishlist")||"[]");a=a.includes(w.dataset.wish)?a.filter(x=>x!==w.dataset.wish):[...a,w.dataset.wish];localStorage.setItem("am_wishlist",JSON.stringify(a));w.classList.toggle("saved",a.includes(w.dataset.wish));w.textContent=a.includes(w.dataset.wish)?"♥":"♡"}));
}

function bookPage(){
  const id=new URLSearchParams(location.search).get("book"),b=BOOKS.find(x=>x.id===id),root=$("#book");
  if(!b){root.innerHTML=`<section class="wrap section narrow"><h1>यह किताब नहीं मिली</h1><a class="btn" href="index.html#books">सारी किताबें देखें</a></section>`;return}
  document.title=`${b.title} — Anjaan Musafir Books`;
  const related=BOOKS.filter(x=>x.id!==b.id&&(x.category===b.category||x.tags.some(t=>b.tags.includes(t)))).slice(0,3);
  root.innerHTML=`<section class="book-hero"><div class="wrap book-grid"><div class="book-cover"><img src="${esc(b.cover)}" alt="${esc(b.title)} — eBook cover"></div><div>${badge(b)}<p class="eyebrow dark">${esc(b.category)}</p><h1>${esc(b.title)}</h1><p class="sub">${esc(b.subtitle)}</p><p class="meta">लेखक: ${esc(b.author)} · ${b.pages} पेज · ${esc(b.language)}</p>${price(b,true)}<div class="actions">${buy(b,"btn primary")}<button class="btn" id="shareBook">Share</button><button class="btn" id="wishBook">♡ बाद में पढ़ूँगा</button></div><p class="micro">Digital eBook (PDF) · Payment और delivery Payhip checkout के अनुसार.</p></div></div></section>
<section class="wrap section narrow"><p class="eyebrow dark">ABOUT THE BOOK</p><h2>इस किताब के बारे में</h2><p>${esc(b.desc)}</p></section>
<section class="wrap section narrow book-toolkit"><div><p class="eyebrow dark">WHAT YOU GET</p><h2>सिर्फ़ PDF नहीं.</h2><p>किताब के साथ practical thinking, exercises और action-oriented ideas पर focus.</p></div><div>${list(b.inside)}</div></section>
<section class="wrap section narrow"><p class="eyebrow dark">IS THIS FOR YOU?</p><h2>यह किताब आपके लिए है अगर…</h2>${list(b.forWho)}</section>
${b.chapters?`<section class="wrap section"><p class="eyebrow dark">INSIDE THE BOOK</p><h2>अध्याय</h2><ol class="chaps">${b.chapters.map(c=>`<li>${esc(c)}</li>`).join("")}</ol></section>`:""}
<section class="wrap section narrow"><p class="eyebrow dark">FAQ</p><h2>अक्सर पूछे जाने वाले सवाल</h2><div class="faq"><details><summary>यह eBook किस भाषा में है?</summary><p>${esc(b.language)} में.</p></details><details><summary>eBook कैसे मिलेगी?</summary><p>Payhip पर payment complete होने के बाद access/download Payhip के checkout flow से मिलेगा.</p></details><details><summary>क्या refund मिलेगा?</summary><p>Digital product होने के कारण सामान्य परिस्थितियों में refund/return नहीं है. पूरी जानकारी Refund Policy में देखें.</p></details><details><summary>Payment या access में समस्या आए तो?</summary><p>${esc(SITE.email)} पर लिखें.</p></details></div></section>
${b.note?`<section class="wrap section narrow note-box">${esc(b.note)}</section>`:""}
<section class="dark-section"><div class="wrap split"><div><p class="eyebrow">YOUR NEXT STEP</p><h2>Read. Reflect. Apply.</h2></div><div><p>अगर यह किताब आपकी current journey से match करती है, तो पढ़ने के बाद एक छोटा action जरूर चुनें.</p>${buy(b,"btn primary")}</div></div></section>
${related.length?`<section class="wrap section"><p class="eyebrow dark">YOU MAY ALSO LIKE</p><h2>आपको यह भी पसंद आ सकती हैं</h2><div class="grid">${related.map(card).join("")}</div></section>`:""}
<div class="sticky-buy">${price(b)}${buy(b,"btn primary")}</div>`;
  const sh=$("#shareBook");if(sh)sh.onclick=async()=>{const u=location.href;if(navigator.share)try{await navigator.share({title:b.title,text:`${b.title} — Anjaan Musafir Books`,url:u})}catch(e){}else await navigator.clipboard?.writeText(u);};
  const wb=$("#wishBook");if(wb){let a=JSON.parse(localStorage.getItem("am_wishlist")||"[]");const update=()=>{wb.textContent=a.includes(b.id)?"♥ Saved":"♡ बाद में पढ़ूँगा";wb.classList.toggle("saved",a.includes(b.id))};wb.onclick=()=>{a=a.includes(b.id)?a.filter(x=>x!==b.id):[...a,b.id];localStorage.setItem("am_wishlist",JSON.stringify(a));update()};update()}
}

function externalLinks(){
  document.querySelectorAll("[id$='Link'],#partnerApply").forEach(el=>{
    const map={channelLink:"whatsappChannel",communityLink:"whatsappCommunity",voteLink:"voteForm",reviewLink:"reviewForm",partnerApply:"partnerForm"};
    const key=map[el.id],url=SITE.links[key];
    if(url)el.href=url;else{el.hidden=true}
  });
}
function offers(){
  const g=$("#offersGrid");if(!g)return;
  const active=SITE.offers.filter(o=>o.active);
  g.innerHTML=active.length?active.map(o=>`<article class="offer-row"><div><span class="badge">${esc(o.badge||"OFFER")}</span><h3>${esc(o.title)}</h3><p>${esc(o.description)}</p></div><div><b>${esc(o.date)}${o.endDate?" → "+esc(o.endDate):""}</b>${o.cta?`<a class="btn" href="${esc(o.cta)}">${esc(o.ctaLabel||"देखें")}</a>`:""}</div></article>`).join(""):`<div class="empty-state"><p class="eyebrow dark">NO ACTIVE OFFER</p><h2>अगला offer जल्द यहाँ दिखेगा.</h2><p>Official Channel join करें ताकि launch और discount की जानकारी सबसे पहले मिले.</p></div>`;
}
function resources(){document.querySelectorAll("[data-placeholder]").forEach(x=>x.addEventListener("click",e=>{e.preventDefault();alert(x.dataset.placeholder+" अभी तैयार होने के बाद यहाँ link लगाया जाएगा.")}))}
function account(){
  const wish=JSON.parse(localStorage.getItem("am_wishlist")||"[]");$("#wishCount")&&($("#wishCount").textContent=wish.length);
}
function chrome(){
  const f=$("#foot");if(f)f.innerHTML=`<div class="wrap footer-grid"><div><p class="brand">ANJAAN MUSAFIR BOOKS</p><p>${esc(SITE.tagline)}</p><p class="micro">Owned & Operated by ${esc(SITE.author)}</p></div><nav><a href="index.html#books">Books</a><a href="circle.html">Circle</a><a href="offers.html">Offers</a><a href="resources.html">Free Resources</a><a href="partner.html">Partner</a><a href="account.html">My Account</a></nav><nav><a href="privacy.html">Privacy Policy</a><a href="terms.html">Terms & Conditions</a><a href="refund.html">Refund Policy</a><a href="contact.html">Contact</a><a href="${esc(SITE.instagram)}" target="_blank" rel="noopener">${esc(SITE.instagramName)}</a></nav></div><p class="wrap copy">© 2026 Anjaan Musafir Books · All Rights Reserved.</p>`;
  const c=$("#contactlinks");if(c)c.innerHTML=`<a href="mailto:${esc(SITE.email)}">${esc(SITE.email)}</a><a href="${esc(SITE.instagram)}" target="_blank" rel="noopener">${esc(SITE.instagramName)}</a>`;
  const m=$("#menu"),n=$("#nav");if(m&&n)m.onclick=()=>{const open=n.classList.toggle("open");m.setAttribute("aria-expanded",open)};
  if(n)n.onclick=e=>{if(e.target.tagName==="A"){n.classList.remove("open");m?.setAttribute("aria-expanded","false")}};
}
chrome();externalLinks();
const page=document.body.dataset.page;
if(page==="home")home(); if(page==="book")bookPage(); if(page==="offers")offers(); if(page==="resources")resources(); if(page==="account")account();
})();